const express=require('express');
const morgan =require('morgan');//if the app is unser production....detailed logs will be skipped as morgan is skipped
const app=express();
 const productroute=require('./routes/productroute');
// const userrouter=require('./routes/userroutes');
// const tablerouter=require('./routes/tableroutes')

//Middleware
// console.log("hi");
if(process.env.NODE_ENV==="development")
{
    app.use(morgan('dev'));
}

app.use(express.json());
app.use(express.static(`${__dirname}/page`));
app.use((req, res, next) => {
    console.log('Hello from the middleware 👋');
    next();
  });

  app.use('/api/v1/bookings',productroute);
//   app.use('/api/v1/user',userrouter);
//   app.use('/api/v1/table',tablerouter);
//   app.all('*', (req, res, next) => {
//     next(new AppError(`Can't find ${req.originalUrl} on this server!`, 404));
//   });
  
//   app.use(globalErrorHandler);

  module.exports=app;